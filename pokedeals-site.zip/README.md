# PokeDeals — affiliate landing page

A single-page, static site showcasing three Whop affiliate products.

Files:
  index.html      the page
  styles.css      all styling (dark, animated, responsive)
  script.js       search/filter, scroll reveals, toast, keyboard shortcuts
  netlify.toml    security + cache headers for Netlify
  _redirects      optional pretty 404 handling
  robots.txt      allow indexing
  sitemap.xml     edit the URL, then submit in Google Search Console

## Deploy on Netlify (2 minutes)

Option A — drag & drop
  1. Unzip this folder.
  2. Go to https://app.netlify.com/drop
  3. Drag the whole folder onto the page.
  4. Done. Rename the site under Site settings > Change site name.

Option B — from Git
  1. Push the folder to a GitHub repo.
  2. Netlify > Add new site > Import an existing project.
  3. Build command: (leave empty)
  4. Publish directory: .
  5. Deploy.

## Deploy on Railway (already on Pro)

Railway expects a server, so this zip includes server.js for that path.
  1. Push this folder to GitHub.
  2. Railway > New Project > Deploy from GitHub repo.
  3. Railway detects server.js and starts it automatically.
  4. Settings > Networking > Generate Domain.
Tip: if you only want a static host, Netlify, Cloudflare Pages or GitHub
Pages are simpler for a plain HTML site. Railway is better when you want
the Node server (custom routes, redirects, analytics at /api/track).

## Before you go live

1. Replace https://your-site-name.netlify.app/ in sitemap.xml with your
   real domain, and add that domain to robots.txt if you want a sitemap line.
2. Change the brand name "PokeDeals" if you'd rather use your own.
3. Swap the meta description / og:title in index.html if you want different
   search wording.
4. Your affiliate IDs are already baked into all 7 CTAs. Do not remove the
   "?a=myloveavni" suffix or the commission won't attribute.

## Legal note

The page includes an affiliate disclosure in the footer and rel="sponsored"
on every affiliate link, which is what the FTC and Google's guidelines ask
for on affiliate pages. Keep it.

## Editing copy

Each tool card is one <article class="card"> block in index.html.
The data-tags attribute powers the search box — add keywords there.
