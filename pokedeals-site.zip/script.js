(function(){
  'use strict';

  /* year */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  /* sticky nav state */
  var nav = document.querySelector('.nav');
  function onScroll(){
    if (!nav) return;
    if (window.scrollY > 12) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* reveal on scroll */
  var revealTargets = document.querySelectorAll('.card, .section-head, .table-wrap, .faq details, .cta-band');
  revealTargets.forEach(function(el){ el.classList.add('reveal'); });

  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(e){
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
    revealTargets.forEach(function(el){ io.observe(el); });
  } else {
    revealTargets.forEach(function(el){ el.classList.add('in'); });
  }

  /* filter */
  var input = document.getElementById('filter');
  var cards = Array.prototype.slice.call(document.querySelectorAll('#cardGrid .card'));
  var empty = document.getElementById('empty');
  var clearBtn = document.getElementById('clearFilter');

  function applyFilter(){
    var q = (input && input.value || '').trim().toLowerCase();
    var shown = 0;
    cards.forEach(function(card){
      var hay = ((card.getAttribute('data-tags') || '') + ' ' + card.textContent).toLowerCase();
      var match = !q || hay.indexOf(q) !== -1;
      card.classList.toggle('hide', !match);
      if (match) shown++;
    });
    if (empty) empty.hidden = shown !== 0;
  }

  if (input) {
    input.addEventListener('input', applyFilter);
    document.addEventListener('keydown', function(e){
      if (e.key === '/' && document.activeElement !== input) {
        e.preventDefault();
        input.focus();
      }
      if (e.key === 'Escape' && document.activeElement === input) {
        input.value = '';
        applyFilter();
        input.blur();
      }
    });
  }
  if (clearBtn) {
    clearBtn.addEventListener('click', function(){
      if (input) { input.value = ''; applyFilter(); input.focus(); }
    });
  }

  /* toast on affiliate click + click tracking hook */
  var toast = document.getElementById('toast');
  var toastTimer = null;
  function showToast(msg){
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function(){ toast.classList.remove('show'); }, 2600);
  }

  document.querySelectorAll('a[href*="whop.com"]').forEach(function(a){
    a.addEventListener('click', function(){
      showToast('Opening checkout — good luck on the drop.');
      // Optional analytics hook: if you add a script that defines
      // window.trackOutbound, it will be called with the destination.
      try {
        if (typeof window.trackOutbound === 'function') {
          window.trackOutbound(a.href, a.textContent.trim());
        }
      } catch (err) { /* tracking must never break navigation */ }
    });
  });

  /* keyboard: pressing "g" jumps to the tools grid */
  document.addEventListener('keydown', function(e){
    var typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '');
    if (e.key === 'g' && !typing && !e.metaKey && !e.ctrlKey && !e.altKey) {
      var grid = document.getElementById('tools');
      if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
